/* rand.h for openSSL */

#include <cyassl/openssl/ssl.h>

