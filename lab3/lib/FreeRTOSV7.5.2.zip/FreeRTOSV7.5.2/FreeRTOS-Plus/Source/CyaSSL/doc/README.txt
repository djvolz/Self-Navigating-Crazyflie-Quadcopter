The CyaSSL manual is availalbe at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf

