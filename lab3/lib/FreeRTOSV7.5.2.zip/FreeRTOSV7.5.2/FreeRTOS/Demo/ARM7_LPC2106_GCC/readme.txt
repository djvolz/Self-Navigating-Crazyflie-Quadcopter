Use one of the following four batch files to build the demo application:

+ rom_arm.bat

Creates an ARM mode release build suitable for programming into flash.

+ ram_arm.bat

Creates an ARM mode debug build suitable for running from RAM.

+ rom_thumb.bat

Creates a THUMB mode release build suitable for programming into flash.

+ ram_thumb.bat

Creates a THUMB mode debug build suitable for running from RAM.

